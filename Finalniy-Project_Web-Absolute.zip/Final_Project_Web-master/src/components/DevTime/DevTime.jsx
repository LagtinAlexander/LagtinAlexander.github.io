import React from 'react';
import './DevTime.module.css';

const DevTime = () => {
    return (
        <p>Its DevTime</p>
        );
}

export default DevTime;