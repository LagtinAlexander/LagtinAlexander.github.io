import React from 'react';
import './Header.module.css';

const Header = () => {
    return (
        <p>Its Header</p>
        );
}

export default Header;