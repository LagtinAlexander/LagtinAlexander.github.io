import React from 'react';
import './Footer.module.css';

const Footer = () => {
    return (
        <p>Its Footer</p>
        );
}

export default Footer;