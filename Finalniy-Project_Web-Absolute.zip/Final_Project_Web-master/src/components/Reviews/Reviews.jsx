import React from 'react';
import './Reviews.module.css';

const Reviews = () => {
    return (
        <p>Its Reviews</p>
        );
}

export default Reviews;