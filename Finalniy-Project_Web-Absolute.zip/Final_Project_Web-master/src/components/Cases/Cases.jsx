import React from 'react';
import './Cases.module.css';

const Cases = () => {
    return (
        <p>Its cases</p>
    );
}

export default Cases;