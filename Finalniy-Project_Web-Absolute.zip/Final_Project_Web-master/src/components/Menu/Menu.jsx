import React from 'react';
import './Menu.module.css';

const Menu = () => {
    return (
        <p>Its Menu</p>
        );
}

export default Menu;