import React from 'react';
import './Competencies.module.css';

const Competencies = () => {
    return (
        <p>Its competencies</p>
        );
}

export default Competencies;