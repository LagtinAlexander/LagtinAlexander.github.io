import React from 'react';
import './Tariffs.module.css';

const Tariffs = () => {
    return (
        <p>Its Tariffs</p>
        );
}

export default Tariffs;