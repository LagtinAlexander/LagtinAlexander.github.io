import React from 'react';
import './Partners.module.css';

const Partners = () => {
    return (
        <p>Its Partners</p>
        );
}

export default Partners;