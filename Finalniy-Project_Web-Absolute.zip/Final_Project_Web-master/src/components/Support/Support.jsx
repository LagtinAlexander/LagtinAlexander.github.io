import React from 'react';
import './Support.module.css';

const Support = () => {
    return (
        <p>Its Support</p>
        );
}

export default Support;