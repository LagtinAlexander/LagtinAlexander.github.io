import React from 'react';
import './FAQ.module.css';

const FAQ = () => {
    return (
        <p>Its FAQ</p>
        );
}

export default FAQ;