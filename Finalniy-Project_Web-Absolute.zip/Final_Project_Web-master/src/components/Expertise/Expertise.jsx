import React from 'react';
import './Expertise.module.css';

const Expertise = () => {
    return (
        <p>Its Expertise</p>
        );
}

export default Expertise;