import React from 'react';
import './Team.module.css';

const Team = () => {
    return (
        <p>Its Team</p>
        );
}

export default Team;